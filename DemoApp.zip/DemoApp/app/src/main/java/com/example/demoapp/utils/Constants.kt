package com.example.demoapp.utils

object ViewPagerType {
    const val APPLICATION = "Application"
    const val SETTINGS = "Settings"
}

object AppStatus{
    const val ACTIVE = "Active"
    const val INACTIVE = "Inactive"
}